# Bank of America Denoise App

A Streamlit web app to denoise and sharpen scanned documents and images for better KYC and fraud detection.

## 🔧 Features
- Median filter to remove salt-and-pepper noise
- Unsharp masking to enhance edges
- Computes PSNR & SSIM metrics
- Download processed output
- Bank of America branding

## 🚀 Installation
```bash
pip install streamlit opencv-python-headless scikit-image pillow numpy
```

## 📦 Usage
```bash
streamlit run app.py
```

## 📁 Folder Structure
```
bank_of_america_denoise_app/
├── app.py
├── README.md
└── assets/
    └── boa_logo.png
```
